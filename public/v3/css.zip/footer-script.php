
 <a id="click-to-top" href="#" class="btn btn-light btn-lg click-to-top" role="button"><i class="fa fa-chevron-up"></i></a>
  <script src="js/jquery.js"></script>
  <script src="js/owl.carousel.js"></script>
 <script src="js/bootstrap.bundle.js"></script>
 <script src="js/bootstrap.js"></script>
 <script src="js/wow.min.js"></script>
 <script src="js/jquery.dataTables.min.js"></script>
 <script src="js/dataTables.bootstrap4.min.js"></script>
<script src="js/dataTables.responsive.min.js"></script>
<script src="js/custom.js"></script>

</body>
</html>