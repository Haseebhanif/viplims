<?php include 'head.php';?>
<?php include 'header.php';?>
  <section class="app-min slider-sec-min bg-white-min pb-0 bg-gray-min">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 text-center col-sm-12 col-xs-12 slide-text m-0-auto ">
          <h1 class="text-white wow fadeInUp mb-4" data-wow-duration="1000ms">Asana and the tools you love, united</h1>
         </div>
      </div>
    </div>
  </section>

   <section class="bg-white-min prod-sectoin-1 customers-min-sec pt-5">
    <div class="container p-0">
      <div class="row">
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-1.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-2.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-3.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-4.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-5.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-6.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-7.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-8.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-9.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-10.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-11.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-12.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-13.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-14.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-15.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-16.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4 col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-17.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-18.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-19.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-20.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-21.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-22.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-23.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-24.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-25.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-26.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-27.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-28.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-29.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-30.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-31.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-32.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-33.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-34.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-35.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-36.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-37.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-38.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-39.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-40.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-41.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-2 col-md-2 col-sm-4  col-xs-6 wow fadeInLeft" data-wow-duration="1000ms"><img src="images/customers/customers-42.png" alt="logo" width="100%" class="text-center"></div>
          <div class="col-lg-12 text-center"><a href="javascript:;" class="custom-btn">See more teams</a></div>


      </div>
    </div>
  </section>
  
   <section class="sectoin-1 bg-gray-min customers-sec-1-min">
    <div class="container">
      <div class="row">
        
         <div class="col-lg-12 col-md-12 col-sm-12 customers-text-min col-xs-12 wow fadeInLeft mb-5" data-wow-duration="1500ms">
          <div class="pord-min-text two text-center"> 
            <h2 class=" wow fadeInUp" data-wow-duration="1000ms">How great teams get great</h2>
            <h2 class=" wow fadeInUp mb-4" data-wow-duration="1000ms">results with Asana</h2>
            <p class=" wow fadeInUp mb-2" data-wow-duration="1000ms">From small businesses to large enterprises, Asana helps</p>
            <p class=" wow fadeInUp mb-2" data-wow-duration="1000ms">teams around the world achieve their biggest goals, faster.</p>
 </div>
        </div>

        <div class="col-lg-3 col-md-3 col-xs-6 col-xs-12">
          <a href="javascript:;" class="customers-text-min-card-link">
          <div class="customers-text-min-card left app-slid-min">
            <img src="images/sony-img.jpg" alt="" width="100%">
            <div class="customers-text-min-card-text">
            <p>Sony Music increased their creative production capacity by 4x with Asana</p>
          
          <span>Read the case study</span>
          </div>
          </div>
          </a>
        </div>
        <div class="col-lg-6 col-md-6 col-xs-6 col-xs-12"><div class="customers-text-min-card center app-slid-min">
          
          <div class="columns p-0">
        <div class="custom1 owl-carousel owl-theme">
          <div class="item"> <img src="images/slider/slide-1.png" width="100%"> </div>
          <div class="item"> <img src="images/slider/slide-1.png" width="100%"> </div>
          <div class="item"> <img src="images/slider/slide-1.png" width="100%"> </div>
          <div class="item"> <img src="images/slider/slide-1.png" width="100%"> </div>
        </div>
      </div>
        </div></div>

        <div class="col-lg-3 col-md-3 col-xs-6 col-xs-12"><div class="customers-text-min-card right app-slid-min">
          
          <a href="javascript:;" class="customers-text-min-card-link">
          <div class="customers-text-min-card left app-slid-min">
            <img src="images/sony-img.jpg" alt="" width="100%">
            <div class="customers-text-min-card-text">
            <p>Sony Music increased their creative production capacity by 4x with Asana</p>
          
          <span>Read the case study</span>
          </div>
          </div>
          </a>
        </div></div>
      </div>
    </div>
  </section>
  
  <section class="sectoin-13 bg-gray-min prod-sectoin-1 big-vid-sectoin-1">
    <div class="container">
      <div class="row">
        <div class="pord-min-text two text-center w-100">
          <h2 class=" wow fadeInUp " data-wow-duration="1100ms">Asana works with the tools</h2>
           <h2 class=" wow fadeInUp mb-4" data-wow-duration="1100ms">you already use</h2>
          <a href="javascript:;" class="custom-btn pl-4 mt-4 bg-grd-min lst-btn pr-4 wow fadeInUp mb-2" data-wow-duration="1500ms">
                     Free trial
                  </a> </div>
      </div>
    </div>
  </section>
  <?php include 'footer.php';?>
  <?php include 'footer-script.php';?>