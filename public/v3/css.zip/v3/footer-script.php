
 <a id="click-to-top" href="#" class="btn btn-light btn-lg click-to-top" role="button"><i class="fa fa-chevron-up"></i></a>
<script src="js/jquery.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/bootstrap.js"></script>



 <script src="js/bootstrap.bundle.js"></script>
 <script src="js/wow.min.js"></script>
<script>
            jQuery(document).ready(function($) {
              $('.loop').owlCarousel({
                center: true,
                nav:false,
                    autoplay:true,
    				autoplayTimeout:10000,

                items: 2,
                loop: true,
                margin: 10,
                responsive: {
                  600: {
                    items: 2
                  }
                }
              });
             
            });

            $(".owl-item").hover(
  function () {
    $(this).addClass("owl-prev");
  },
  function () {
    $(this).removeClass("owl-prev");
  }
);
          </script>
      <script type="text/javascript">
$(document).ready(function(){
  $(window).scroll(function () {
      if ($(this).scrollTop() > 50) {
        $('#click-to-top').fadeIn();
      } else {
        $('#click-to-top').fadeOut();
      }
    });
    // scroll body to 0px on click
    $('#click-to-top').click(function () {
      $('body,html').animate({
        scrollTop: 0
      }, 400);
      return false;
    });
});

      </script>
<script>



var wow = new WOW({
    	offset:100,        // distance to the element when triggering the animation (default is 0)
    	mobile:false       // trigger animations on mobile devices (default is true)
  	});
	wow.init();

</script>
<script type="text/javascript">

      </script>
      <script type="text/javascript">
$('.sub-menu').on('click',function(){
  $('.user-drop-min-sub ').find('ul').slideToggle(350);
});

$('.sub-menu').on('click',function(){
  $('.down-arrow').toggleClass('fa-angle-up fa-angle-down');
});


$(document).ready(function(){
  $(".sub-menu-drop").click(function(){
    $(".sub-menu-drop").toggleClass("sub-menu-btn ");
  });
});
      </script>
</body>
</html>