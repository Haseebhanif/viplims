<?php include 'head.php';?>
<?php include 'header.php';?>
   
      
      
      <section class="pricing-sec-min">
      
      
      <div class="container">
    <div class="pricing card-deck flex-column flex-md-row mt-5 pt-2">
        <div class="card card-pricing text-center card-one px-3 mb-2 wow fadeInLeft"  data-wow-duration="1000ms">
            <span class="h6 w-60 rounded-top text-white pkg-name">Starter</span>
            <div class="bg-transparent card-header pt-0 border-0">
                <h1 class="h1 font-weight-normal prc-text text-center mb-0"><i class="fa fa-dollar"></i><span class="price">3</span><span class="h6 ml-2">/ per month</span></h1>
            </div>
            <div class="card-body pt-0">
                <ul class="list-unstyled mb-4">
                    <li>Up to 5 users</li>
                    <li>Basic support on Github</li>
                    <li>Monthly updates</li>
                    <li>Free cancelation</li>
                </ul>
                <button type="button" class="btn btn-outline-secondary mb-3">Order now</button>
            </div>
        </div>
      <div class="card card-pricing text-center card-tow px-3 mb-2 wow fadeInRight"  data-wow-duration="1300ms">
            <span class="h6 w-60 rounded-top text-white pkg-name">Starter</span>
            <div class="bg-transparent card-header pt-0 border-0">
                <h1 class="h1 font-weight-normal prc-text text-center mb-0"><i class="fa fa-dollar"></i><span class="price">3</span><span class="h6 ml-2">/ per month</span></h1>
            </div>
            <div class="card-body pt-0">
                <ul class="list-unstyled mb-4">
                    <li>Up to 5 users</li>
                    <li>Basic support on Github</li>
                    <li>Monthly updates</li>
                    <li>Free cancelation</li>
                </ul>
                <button type="button" class="btn btn-outline-secondary mb-3">Order now</button>
            </div>
        </div>
         
      <div class="card card-pricing text-center card-three px-3 mb-2 wow fadeInLeft"  data-wow-duration="1500ms">
            <span class="h6 w-60 rounded-top text-white pkg-name">Starter</span>
            <div class="bg-transparent card-header pt-0 border-0">
                <h1 class="h1 font-weight-normal prc-text text-center mb-0"><i class="fa fa-dollar"></i><span class="price">3</span><span class="h6 ml-2">/ per month</span></h1>
            </div>
            <div class="card-body pt-0">
                <ul class="list-unstyled mb-4">
                    <li>Up to 5 users</li>
                    <li>Basic support on Github</li>
                    <li>Monthly updates</li>
                    <li>Free cancelation</li>
                </ul>
                <button type="button" class="btn btn-outline-secondary mb-3">Order now</button>
            </div>
        </div>
        <div class="card card-pricing text-center card-four px-3 mb-2 wow fadeInLeft"  data-wow-duration="2000ms">
            <span class="h6 w-60 rounded-top text-white pkg-name">Starter</span>
            <div class="bg-transparent card-header pt-0 border-0">
                <h1 class="h1 font-weight-normal prc-text text-center mb-0"><i class="fa fa-dollar"></i><span class="price">3</span><span class="h6 ml-2">/ per month</span></h1>
            </div>
            <div class="card-body pt-0">
                <ul class="list-unstyled mb-4">
                    <li>Up to 5 users</li>
                    <li>Basic support on Github</li>
                    <li>Monthly updates</li>
                    <li>Free cancelation</li>
                </ul>
                <button type="button" class="btn btn-outline-secondary mb-3">Order now</button>
            </div>
        </div>
    </div>
</div>
</section>
      <?php include 'footer.php';?>
      <?php include 'footer-script.php';?>